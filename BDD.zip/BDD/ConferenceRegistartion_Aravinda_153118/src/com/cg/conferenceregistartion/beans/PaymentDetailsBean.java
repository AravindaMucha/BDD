package com.cg.conferenceregistartion.beans;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class PaymentDetailsBean {

	@FindBy(how=How.ID,id="txtCardholderName")
	private WebElement cardHolderName;
	
	@FindBy(how=How.ID,id="txtDebit")
	private WebElement debitCradNumber;
	
	@FindBy(how=How.ID,id="txtCvv")
	private WebElement cvv;
	
	@FindBy(how=How.ID,id="txtMonth")
	private WebElement expirationMonth;
	
	@FindBy(how=How.ID,id="txtYear")
	private WebElement expirationYear;
	
	@FindBy(how=How.ID,id="btnPayment")
	private WebElement makePayment;

	public PaymentDetailsBean() {
		
	}

	public String getCardHolderName() {
		return cardHolderName.getAttribute("value");
	}

	public void setCardHolderName(String cardHolderName) {
		this.cardHolderName.sendKeys(cardHolderName);;
	}

	public String getDebitCradNumber() {
		return debitCradNumber.getAttribute("value");
	}

	public void setDebitCradNumber(String debitCradNumber) {
		this.debitCradNumber.sendKeys(debitCradNumber);
	}

	public String getCvv() {
		return cvv.getAttribute("value");
	}

	public void setCvv(String cvv) {
		this.cvv.sendKeys(cvv);
	}

	public String getExpirationMonth() {
		return expirationMonth.getAttribute("value");
	}

	public void setExpirationMonth(String expirationMonth) {
		this.expirationMonth.sendKeys(expirationMonth);
	}

	public String getExpirationYear() {
		return expirationYear.getAttribute("value");
	}

	public void setExpirationYear(String expirationYear) {
		this.expirationYear.sendKeys(expirationYear);
	}
	
	
	public void clickMakePaymentPageLink() {
		makePayment.click();
	}
	
	
	
	
}
