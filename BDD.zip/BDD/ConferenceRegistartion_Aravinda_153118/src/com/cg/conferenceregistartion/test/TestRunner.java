package com.cg.conferenceregistartion.test;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(
		features= {"Features"},
		glue= {"com.cg.conferenceregistartion.stepdefinitions"}
		)
public class TestRunner {
	
}
