package com.cg.conferenceregistartion.stepdefinitions;

import org.junit.Assert;
import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.conferenceregistartion.beans.ConferenceRegistrationBean;
import com.cg.conferenceregistartion.beans.PaymentDetailsBean;

import cucumber.api.PendingException;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class ConferenceRoomBookingStepDefinitions {

	public WebDriver driver;
	public ConferenceRegistrationBean registerBean;
	public PaymentDetailsBean paymentBean;
	
	@Before
	public void setupStepEnv() {
		System.setProperty("webdriver.chrome.driver", "D:\\Softwares\\chromedriver.exe");
	}
	
	@Given("^User Launched the Application Browser$")
	public void user_Launched_the_Application_Browser() throws Throwable {
		driver = new ChromeDriver();
	}

	@Given("^User is on 'ConferenceRegistartion\\.html' page$")
	public void user_is_on_ConferenceRegistartion_html_page() throws Throwable {
		driver.get("D:\\Practice\\BDD\\ConferenceRegistartion_Aravinda_153118\\ConferenceRegistartion.html");
		driver.manage().window().maximize();
		registerBean = new ConferenceRegistrationBean();
		PageFactory.initElements(driver, registerBean);
		
		
	}

	@When("^User Clicks on 'Next'  link without entering 'FirstName'$")
	public void user_Clicks_on_Next_link_without_entering_FirstName() throws Throwable {
		Thread.sleep(500);
		registerBean.clickNextPageLink();
	}

	@Then("^'Please fill the First Name' message should be displayed$")
	public void please_fill_the_First_Name_message_should_be_displayed() throws Throwable {
		String actualMessage=driver.switchTo().alert().getText();
		String expectedMessage="Please fill the First Name";
		Assert.assertEquals(expectedMessage, actualMessage);
	}

	@When("^User Clicks on 'Next' link without entering 'LastName'$")
	public void user_Clicks_on_Next_link_without_entering_LastName() throws Throwable {
		driver.switchTo().alert().dismiss();
		Thread.sleep(500);
		registerBean.setFirstName("Aravinda");
		Thread.sleep(500);
		registerBean.clickNextPageLink();
	}

	@Then("^'Please fill the Last Name' message should be displayed$")
	public void please_fill_the_Last_Name_message_should_be_displayed() throws Throwable {
		String actualMessage=driver.switchTo().alert().getText();
		String expectedMessage="Please fill the Last Name";
		Assert.assertEquals(expectedMessage, actualMessage);
	}

	@When("^User Clicks on 'Next' link after entering invalid 'Email' address$")
	public void user_Clicks_on_Next_link_after_entering_invalid_Email_address() throws Throwable {
		    driver.switchTo().alert().dismiss();
		    Thread.sleep(500);
		    registerBean.setLastName("Mucha");
		    Thread.sleep(500);
			registerBean.setEmail("aravinda.mucha.66");
			Thread.sleep(500);
			registerBean.clickNextPageLink();
	}

	@Then("^'Please fill the Email' message should be displayed$")
	public void please_fill_the_Email_message_should_be_displayed() throws Throwable {
		String actualMessage=driver.switchTo().alert().getText();
		String expectedMessage="Please enter valid Email Id.";
		Assert.assertEquals(expectedMessage, actualMessage);
	}

	@When("^User Clicks on 'Next' link without entering 'Contact No'$")
	public void user_Clicks_on_Next_link_without_entering_Contact_No() throws Throwable {
		driver.switchTo().alert().dismiss();
		Thread.sleep(500);
		registerBean.setEmail("aravinda.mucha@capgemini.com");
		Thread.sleep(500);
		registerBean.clickNextPageLink();
	}

	@Then("^'Please fill the Contact No\\.' message should be displayed$")
	public void please_fill_the_Contact_No_message_should_be_displayed() throws Throwable {
		String actualMessage=driver.switchTo().alert().getText();
		String expectedMessage="Please fill the Contact No.";
		Assert.assertEquals(expectedMessage, actualMessage);
	}

	@When("^User Clicks on 'Next' link after entering invalid 'Contact No'$")
	public void user_Clicks_on_Next_link_after_entering_invalid_Contact_No() throws Throwable {
		driver.switchTo().alert().dismiss();
		Thread.sleep(500);
		registerBean.setContactNo("567891234");
		Thread.sleep(500);
		registerBean.clickNextPageLink();
	}

	@Then("^'Please enter valid Contact no\\.' message should be displayed$")
	public void please_enter_valid_Contact_no_message_should_be_displayed() throws Throwable {
		String actualMessage=driver.switchTo().alert().getText();
		String expectedMessage="Please enter valid Contact no.";
		Assert.assertEquals(expectedMessage, actualMessage);
	}

	@When("^User Clicks on 'Next' link without selecting  'Number of people attending'$")
	public void user_Clicks_on_Next_link_without_selecting_Number_of_people_attending() throws Throwable {
		driver.switchTo().alert().dismiss();
		Thread.sleep(500);
		registerBean.setContactNo("9652160279");
		Thread.sleep(500);
		registerBean.clickNextPageLink();
	}

	@Then("^'Please fill the Number of people attending' message should be displayed$")
	public void please_fill_the_Number_of_people_attending_message_should_be_displayed() throws Throwable {
		
		String actualMessage=driver.switchTo().alert().getText();
		String expectedMessage="Please fill the Number of people attending";
		Assert.assertEquals(expectedMessage, actualMessage);;
	}

	@When("^User Clicks on 'Next' link without entereing  'Building Name & Room No'$")
	public void user_Clicks_on_Next_link_without_entereing_Building_Name_Room_No() throws Throwable {
		driver.switchTo().alert().dismiss();
		Thread.sleep(500);
		registerBean.setnoOfPeopleAttending("3");
		Thread.sleep(500);
		registerBean.clickNextPageLink();
	}

	@Then("^'Please fill the Building & Room No' message should be displayed$")
	public void please_fill_the_Building_Room_No_message_should_be_displayed() throws Throwable {
		String actualMessage=driver.switchTo().alert().getText();
		String expectedMessage="Please fill the Building & Room No";
		Assert.assertEquals(expectedMessage, actualMessage);
	}

	@When("^User Clicks on 'Next' link without entereing  'Area Name'$")
	public void user_Clicks_on_Next_link_without_entereing_Area_Name() throws Throwable {
		driver.switchTo().alert().dismiss();
		Thread.sleep(500);
		registerBean.setbuildingNameAndRoomNo("Room No:304 ,ERC, Capgemini, Pune");
		Thread.sleep(500);
		registerBean.clickNextPageLink();
	}

	@Then("^'Please fill the Area name' message should be displayed$")
	public void please_fill_the_Area_name_message_should_be_displayed() throws Throwable {
		String actualMessage=driver.switchTo().alert().getText();
		String expectedMessage="Please fill the Area name";
		Assert.assertEquals(expectedMessage, actualMessage);
	}

	@When("^User Clicks on'Next' link without selecting  'City'$")
	public void user_Clicks_on_Next_link_without_selecting_City() throws Throwable {
		driver.switchTo().alert().dismiss();
		Thread.sleep(500);
		registerBean.setAreaName("Hinjewadi, Pune");
		Thread.sleep(500);
		registerBean.clickNextPageLink();
	}

	@Then("^'Please select city' message should be displayed$")
	public void please_select_city_message_should_be_displayed() throws Throwable {
		String actualMessage=driver.switchTo().alert().getText();
		String expectedMessage="Please select city";
		Assert.assertEquals(expectedMessage, actualMessage);
	}

	@When("^User Clicks on 'Next' link without selecting  'State'$")
	public void user_Clicks_on_Next_link_without_selecting_State() throws Throwable {
		driver.switchTo().alert().dismiss();
		Thread.sleep(500);
		registerBean.setCity("Pune");
		Thread.sleep(500);
		registerBean.clickNextPageLink();
	}

	@Then("^'Please select state' message should be displayed$")
	public void please_select_state_message_should_be_displayed() throws Throwable {
		String actualMessage=driver.switchTo().alert().getText();
		String expectedMessage="Please select state";
		Assert.assertEquals(expectedMessage, actualMessage);
	}

	@When("^User Clicks on 'Next' link without selecting  'MemberShip Status '$")
	public void user_Clicks_on_Next_link_without_selecting_MemberShip_Status() throws Throwable {
		
		driver.switchTo().alert().dismiss();
		Thread.sleep(500);
		registerBean.setState("Maharashtra");
		Thread.sleep(500);
		registerBean.clickNextPageLink();
	}

	@Then("^'Please Select MemeberShip status' message should be displayed$")
	public void please_Select_MemeberShip_status_message_should_be_displayed() throws Throwable {
		
		String actualMessage=driver.switchTo().alert().getText();
		String expectedMessage="Please Select MemeberShip status";
		Assert.assertEquals(expectedMessage, actualMessage);
	}

	@When("^User Clicks on 'Next' link after entering Valid set of information$")
	public void user_Clicks_on_Next_link_after_entering_Valid_set_of_information() throws Throwable {
		driver.switchTo().alert().dismiss();
		Thread.sleep(1000);
		/*registerBean.setFirstName("Aravinda");
		Thread.sleep(1000);
		registerBean.setLastName("Mucha");
		Thread.sleep(1000);
		registerBean.setEmail("mucha.aravinda@capgemini.com");
		Thread.sleep(1000);
		registerBean.setContactNo("9652160279");
		Thread.sleep(1000);
		registerBean.setnoOfPeopleAttending("3");
		Thread.sleep(1000);
		registerBean.setbuildingNameAndRoomNo("Room No:304 ,ERC, Capgemini, Pune");
		Thread.sleep(1000);
		registerBean.setAreaName("Hinjewadi, Pune");
		Thread.sleep(1000);
		registerBean.setCity("Pune");
		Thread.sleep(1000);*/
		registerBean.setState("Maharashtra");
		Thread.sleep(500);
		registerBean.setMemberStatus("member");
		Thread.sleep(500);
		registerBean.clickNextPageLink();
		
		
	}

	@Then("^'Personal details are validated\\.' message should be displayed$")
	public void personal_details_are_validated_message_should_be_displayed() throws Throwable {
//		
		String actualMessage=driver.switchTo().alert().getText();
		String expectedMessage="Personal details are validated.";
		Assert.assertEquals(expectedMessage, actualMessage);
		
	}
	
	@When("^User is on 'PaymentDetails Page' User Clicks on 'MakePayment' without entering 'Card Holder Name'$")
	public void user_is_on_PaymentDetails_Page_User_Clicks_on_MakePayment_without_entering_Card_Holder_Name() throws Throwable {
		
		Alert jsAlert = driver.switchTo().alert();
		if(jsAlert.getText().equals("Personal details are validated."))
		{
			Thread.sleep(1000);
			jsAlert.accept();
			driver.navigate().to("D:\\Practice\\BDD\\ConferenceRegistartion_Aravinda_153118\\PaymentDetails.html");
			driver.manage().window().maximize();
			paymentBean = PageFactory.initElements(driver, PaymentDetailsBean.class);
		}
		else
		{
			
		}
		paymentBean.clickMakePaymentPageLink();
		
	
	}

	
	@Then("^'Please fill the Card holder name' message should be displayed$")
	public void please_fill_the_Card_holder_name_message_should_be_displayed() throws Throwable {
		 String actualMessage=driver.switchTo().alert().getText();
			String expectedMessage="Please fill the Card holder name";
			Assert.assertEquals(expectedMessage, actualMessage);
		
	}

	@When("^User Clicks on 'MakePayment' without entering 'Debit card Number'$")
	public void user_Clicks_on_MakePayment_without_entering_Debit_card_Number() throws Throwable {
			driver.switchTo().alert().dismiss();
			Thread.sleep(1000);
			paymentBean.setCardHolderName("Aravinda Mucha");
			Thread.sleep(1000);
			paymentBean.clickMakePaymentPageLink();
	}

	@Then("^'Please fill the  Debit Card Number' meassage should be displayed$")
	public void please_fill_the_Debit_Card_Number_meassage_should_be_displayed() throws Throwable {
		String actualMessage=driver.switchTo().alert().getText();
		String expectedMessage="Please fill the Debit card Number";
		Assert.assertEquals(expectedMessage, actualMessage);
	}

	
	
	@When("^User Clicks on 'MakePayment' without entering 'Cvv'$")
	public void user_Clicks_on_MakePayment_without_entering_Cvv() throws Throwable {
		driver.switchTo().alert().dismiss();
		Thread.sleep(1000);
		paymentBean.setDebitCradNumber("153ACS896");
		Thread.sleep(1000);
		paymentBean.clickMakePaymentPageLink();
	}

	@Then("^'Cvv' meassage should be displayed$")
	public void cvv_meassage_should_be_displayed() throws Throwable {
		String actualMessage=driver.switchTo().alert().getText();
		String expectedMessage="Please fill the CVV";
		Assert.assertEquals(expectedMessage, actualMessage);
		
	}
	
	@When("^User Clicks on 'MakePayment' without entering 'expiration month'$")
	public void user_Clicks_on_MakePayment_without_entering_expiration_month() throws Throwable {
		driver.switchTo().alert().dismiss();
		 
		paymentBean.setCvv("123");
		paymentBean.clickMakePaymentPageLink();

	}

	@Then("^'Please fill expiration month' message should be displayed$")
	public void please_fill_expiration_month_message_should_be_displayed() throws Throwable {
		String actualMessage=driver.switchTo().alert().getText();
		String expectedMessage="Please fill expiration month";
		Assert.assertEquals(expectedMessage, actualMessage);
	}

	@When("^User Clicks on 'MakePayment' without entering 'expiration year'$")
	public void user_Clicks_on_MakePayment_without_entering_expiration_year() throws Throwable {
		driver.switchTo().alert().dismiss();
		Thread.sleep(1000);
		paymentBean.setExpirationMonth("Aug");
		Thread.sleep(1000);
		paymentBean.clickMakePaymentPageLink();
	}

	@Then("^'Please fill expiration year' message should be displayed$")
	public void please_fill_expiration_year_message_should_be_displayed() throws Throwable {
		String actualMessage=driver.switchTo().alert().getText();
		String expectedMessage="Please fill the expiration year";
		Assert.assertEquals(expectedMessage, actualMessage);
	}

	@When("^User Clicks on 'MakePayment' button after entering Valid set of information$")
	public void user_Clicks_on_MakePayment_button_after_entering_Valid_set_of_information() throws Throwable {
		driver.switchTo().alert().dismiss();
		Thread.sleep(1000);
		paymentBean.setExpirationYear("2025");
		Thread.sleep(1000);
		paymentBean.clickMakePaymentPageLink();
	}

	@Then("^'Conference Room Booking Successfully done!!!' message should be displayed\\.$")
	public void conference_Room_Booking_Successfully_done_message_should_be_displayed() throws Throwable {
		String actualMessage=driver.switchTo().alert().getText();
		String expectedMessage="Conference Room Booking successfully done!!!";
		Assert.assertEquals(expectedMessage, actualMessage);
		Thread.sleep(1000);
		driver.close();
	}
	
}
