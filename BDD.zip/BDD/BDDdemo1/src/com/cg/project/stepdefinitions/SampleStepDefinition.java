package com.cg.project.stepdefinitions;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;


public class SampleStepDefinition {

	public WebDriver driver;
	
	@Before(order = 1)
	public void setupStepEnv() {
		//System.out.println("setupStepEnv()");
		System.setProperty("webdriver.chrome.driver", "D:\\Softwares\\chromedriver.exe");
	}

//	@Before(order = 2)
//	public void setupStepEnv2() {
//		System.out.println("setupStepEnv2()");
//	}

	@Given("^user want to access 'www\\.google\\.com'$")
	public void user_want_to_access_www_google_com() throws Throwable {
		driver = new ChromeDriver();
	}

	@When("^user will open google chrome$")
	public void user_will_open_google_chrome() throws Throwable {
		driver.get("http://www.google.com");
	}

	@When("^will enter 'www\\.google\\.com' in address bar$")
	public void will_enter_www_google_com_in_address_bar() throws Throwable {
		
	}

	@Then("^display the home page of 'www\\.google\\.com'$")
	public void display_the_home_page_of_www_google_com() throws Throwable {
		String actualTitle = driver.getTitle();
		Assert.assertEquals("Google", actualTitle);

	}

}
