package com.cg.project.stepdefinitions;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.project.beans.RegisterBean;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class RegisterStepDefinitions {

	public WebDriver driver;
	public RegisterBean registerBean;

	@Before(order = 1)
	public void setupStepEnv() {
		System.setProperty("webdriver.chrome.driver", "D:\\Softwares\\chromedriver.exe");
	}

	@Given("^user want to register to 'https://www\\.naukri\\.com/'$")
	public void user_want_to_register_to_https_www_naukri_com() throws Throwable {
		driver = new ChromeDriver();
	}

	@Given("^user is on restration page$")
	public void user_is_on_restration_page() throws Throwable {
		driver.get("https://www.naukri.com/account/createaccount");
		registerBean = new RegisterBean();
		PageFactory.initElements(driver, registerBean);

	}

	@When("^user want to register as a fresher$")
	public void user_want_to_register_as_a_fresher() throws Throwable {
		registerBean.clickFresherButton();
		//driver.findElement(By.xpath("/html/body/div/form/div[1]/div/button"));
	}
       
	@Then("^user should navigate to basicdetails page$")
	public void user_should_navigate_to_basicdetails_page() throws Throwable {
		String actualTitle = driver.getTitle();
		String expectedTitle = "Resume Manager - Post Resume Online - Submit your CV - Naukri.com";
		Assert.assertEquals(expectedTitle, actualTitle);
	}
	@When("^user enters 'Name' with 'AravindaMucha'$")
	public void user_enters_Name_with_AravindaMucha() throws Throwable {
		registerBean.setName("doglie");
	}

	@When("^user enter 'mailid' with 'aravindamucha(\\d+)@gmail\\.com'$")
	public void user_enter_mailid_with_aravindamucha_gmail_com(int arg1) throws Throwable {
		registerBean.setMailid("dog895@gmail.com");
	}

	@When("^user enter 'createPassword' with 'Aravinda@(\\d+)'$")
	public void user_enter_createPassword_with_Aravinda(int arg1) throws Throwable {
		registerBean.setPassword("Dog123");
	}

	@When("^user enter 'mobile number' with '(\\d+)'$")
	public void user_enter_mobile_number_with(int arg1) throws Throwable {
		registerBean.setMobileNumber("9999138920");
	}

	@When("^user enter 'current location' as 'location'$")
	public void user_enter_current_location_as_location() throws Throwable {

		registerBean.setCurrentLocation("Chennai");
		//registerBean.submit();

	}

	@When("^will 'upload resume'$")
	public void will_upload_resume() throws Throwable {
		registerBean.setResumeupload("D:\\Users\\muaravin\\Desktop\\Aravinda-153118-CV.pdf");
	}

	@When("^user click on 'Register now'$")
	public void user_click_on_Register_now() throws Throwable {
		registerBean.clickRegisterButton();
	}

	@Then("^user should see 'https://www\\.naukri\\.com/account/register/education'$")
	public void user_should_see_https_www_naukri_com_account_register_education() throws Throwable {
		String actualTitle = driver.getTitle();
		String expectedTitle = "Resume Manager - Post Resume Online - Submit your CV - Naukri.com";
		Assert.assertEquals(expectedTitle, actualTitle);
		Thread.sleep(3000);
		driver.navigate().refresh();
	}

	/*@Then("^user should see 'https://www\\.naukri\\.com/account/register/education'$")
	public void user_should_see_https_www_naukri_com_account_register_education() throws Throwable {
		String actualTitle = driver.getTitle();
		String expectedTitle = "Resume Manager - Post Resume Online - Submit your CV - Naukri.com";
		Assert.assertEquals(expectedTitle, actualTitle);
	}*/

	@When("^user will choose 'Highest Qualification'$")
	public void user_will_choose_Highest_Qualification() throws Throwable {
		registerBean.clickQualification();
		registerBean.clickSelectQualification();

		//driver.findElement(By.xpath("//*[@id=\"educationDetailForm\"]/edu-section/section/edu-qualification/div/div[1]/div/div/div[1]/ul/li/div/label/input")).click();
		//driver.findElement(By.xpath("//*[@id=\"educationDetailForm\"]/edu-section/section/edu-qualification/div/div[1]/div/div/div[2]/ul/li[4]/div/div/span")).click();
	}

	@When("^user will choose 'Board'$")
	public void user_will_choose_Board() throws Throwable {
		registerBean.clickBoard();
		registerBean.clickSelectBoard();
//		driver.findElement(By.xpath("//*[@id=\"educationDetailForm\"]/edu-section/section/div/resman-school-twelfth/div[1]/div/div/div/div[1]/ul/li/div/label/input")).click();
//		driver.findElement(By.xpath("//*[@id=\"educationDetailForm\"]/edu-section/section/div/resman-school-twelfth/div[1]/div/div/div/div[2]/ul/li[2]/div/div/span")).click();

	}

	@When("^user will choose 'year of passing'$")
	public void user_will_choose_year_of_passing() throws Throwable {
		
		registerBean.clickYearOfPassing();
		registerBean.clickSelectYearOfPassing();
		
//		driver.findElement(By.xpath("//*[@id=\"educationDetailForm\"]/edu-section/section/div/resman-school-twelfth/div[2]/div/div/div/div[1]/ul/li/div/label/input")).click();
//		driver.findElement(By.xpath("//*[@id=\"educationDetailForm\"]/edu-section/section/div/resman-school-twelfth/div[2]/div/div/div/div[2]/ul/li[2]/div/div/span")).click(); 

	}

	@When("^user will choose 'medium'$")
	public void user_will_choose_medium() throws Throwable {
		registerBean.clickMedium();
		registerBean.clickSelectMedium();
		//driver.findElement(By.xpath("//*[@id=\"educationDetailForm\"]/edu-section/section/div/resman-school-twelfth/div[3]/div/div/div/div[1]/ul/li/div/label/input")).click();
		//driver.findElement(By.xpath("//*[@id=\"educationDetailForm\"]/edu-section/section/div/resman-school-twelfth/div[3]/div/div/div/div[2]/ul/li[3]/div/div/span")).click(); 

	}

	@When("^user will choose 'Percentage'$")
	public void user_will_choose_Percentage() throws Throwable {
		registerBean.clickPercentage();
		registerBean.clickSelectPercentage();
		//driver.findElement(By.xpath("//*[@id=\"educationDetailForm\"]/edu-section/section/div/resman-school-twelfth/div[4]/div/div/div/div[1]/ul/li/div/label/input")).click();
		//driver.findElement(By.xpath("//*[@id=\"educationDetailForm\"]/edu-section/section/div/resman-school-twelfth/div[4]/div/div/div/div[2]/ul/li[13]/div/div/span")).click();

	}

	@When("^user will choose 'Skills'$")
	public void user_will_choose_Skills() throws Throwable {
		registerBean.setSkills("PHP");
		//WebElement element = driver.findElement(By.xpath("//*[@id=\"selSkillCont\"]/div/ul/li/suggestor/div/div/input"));
		//element.sendKeys("HTML");
	}

	@When("^user will click on 'Continue'$")
	public void user_will_click_on_Continue() throws Throwable {
		registerBean.clickContinueButton();
//		WebElement element = driver.findElement(By.xpath("//*[@id=\"educationDetailForm\"]/div/div/div/button"));
//		element.click();
	}

	@Then("^user should see 'https://www\\.naukri\\.com/account/register/profilecompletion'$")
	public void user_should_see_https_www_naukri_com_account_register_profilecompletion() throws Throwable {
		String actualTitle = driver.getTitle();
		String expectedTitle = "Resume Manager - Post Resume Online - Submit your CV - Naukri.com";
		Assert.assertEquals(expectedTitle, actualTitle);
		Thread.sleep(3000);
		driver.navigate().refresh();
	}
}
