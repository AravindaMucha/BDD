package com.cg.project.beans;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class RegisterBean {
	
	@FindBy(name = "userType")
	WebElement Fresherregisterbtn;
	
	@FindBy(how = How.ID, id="fname")
	WebElement name;
	
	@FindBy(how = How.ID, id = "email")
	WebElement mailid;
	
	@FindBy(name = "password")
	WebElement password;
	
	@FindBy(name = "number")
	WebElement MobileNumber;
	
	@FindBy(xpath="//*[@id=\"basicDetailForm\"]/resman-location/div/div/div[1]/div/div[1]/ul/li/div/label/input")
	WebElement currentLocation;
	
	//@FindBy(className = "clicked")
	@FindBy(xpath = "//*[@id=\"basicDetailForm\"]/resman-uploader/div/div[1]/span[1]/input")
	WebElement resumeupload;
	
	@FindBy(name = "basicDetailSubmit")
	WebElement registerbtn;
	

	@FindBy(how=How.XPATH,xpath="//*[@id=\"educationDetailForm\"]/edu-section/section/edu-qualification/div/div[1]/div/div/div[1]/ul/li/div/label/input")
	WebElement qualification;
	
	@FindBy(how=How.XPATH,xpath="//*[@id=\"educationDetailForm\"]/edu-section/section/edu-qualification/div/div[1]/div/div/div[2]/ul/li[4]/div/div/span")
	WebElement selectQualification;
	
	@FindBy(how=How.XPATH,xpath="//*[@id=\"educationDetailForm\"]/edu-section/section/div/resman-school-twelfth/div[1]/div/div/div/div[1]/ul/li/div/label/input")
	WebElement board;
	
	@FindBy(how=How.XPATH,xpath="//*[@id=\"educationDetailForm\"]/edu-section/section/div/resman-school-twelfth/div[1]/div/div/div/div[2]/ul/li[2]/div/div/span")
	WebElement selectBoard;
	
	@FindBy(how=How.XPATH,xpath="//*[@id=\"educationDetailForm\"]/edu-section/section/div/resman-school-twelfth/div[2]/div/div/div/div[1]/ul/li/div/label/input")
	WebElement yearOfPassing;
	
	@FindBy(how=How.XPATH,xpath="//*[@id=\"educationDetailForm\"]/edu-section/section/div/resman-school-twelfth/div[2]/div/div/div/div[2]/ul/li[2]/div/div/span")
	WebElement selectYearOfPassing;
	
	@FindBy(how=How.XPATH,xpath="//*[@id=\"educationDetailForm\"]/edu-section/section/div/resman-school-twelfth/div[3]/div/div/div/div[1]/ul/li/div/label/input")
	WebElement medium;
	
	@FindBy(how=How.XPATH,xpath="//*[@id=\"educationDetailForm\"]/edu-section/section/div/resman-school-twelfth/div[3]/div/div/div/div[2]/ul/li[3]/div/div/span")
	WebElement selectMedium;
	
	@FindBy(how=How.XPATH,xpath="//*[@id=\"educationDetailForm\"]/edu-section/section/div/resman-school-twelfth/div[4]/div/div/div/div[1]/ul/li/div/label/input")
	WebElement percentage;
	
	@FindBy(how=How.XPATH,xpath="//*[@id=\"educationDetailForm\"]/edu-section/section/div/resman-school-twelfth/div[4]/div/div/div/div[2]/ul/li[8]/div/div/span")
	WebElement selectPercentage;
	
	@FindBy(how=How.XPATH,xpath="//*[@id=\"selSkillCont\"]/div/ul/li/suggestor/div/div/input")
	WebElement skills;	
	
	@FindBy(how=How.XPATH,xpath="//*[@id=\"educationDetailForm\"]/div/div/div/button")
	WebElement continueButton;
	
	@FindBy(how=How.XPATH,xpath="//*[@id=\"profileCompleteForm\"]/div[8]/div[2]/a")
	WebElement skipStep;
	public RegisterBean() {
		
	}
	

	public String getName() {
		return name.getAttribute("value");
	}

	public void setName(String name) {
		this.name.sendKeys(name);
	}

	public String getMailid() {
		return mailid.getAttribute("value");
	}

	public void setMailid(String mailid) {
		this.mailid.sendKeys(mailid);
	}

	public String getPassword() {
		return password.getAttribute("value");
	}

	public void setPassword(String password) {
		this.password.sendKeys(password);
	}

	public String getMobileNumber() {
		return MobileNumber.getAttribute("value");
	}

	public void setMobileNumber(String mobileNumber) {
		this.MobileNumber.sendKeys(mobileNumber);
	}

	public String getCurrentLocation() {
		return currentLocation.getAttribute("value");
	}

	public void setCurrentLocation(String currentLocation) {
		this.currentLocation.sendKeys(currentLocation);
	}
	
	public String getResumeupload() {
		return resumeupload.getAttribute("value");
	}

	public void setResumeupload(String resumeupload) {
		this.resumeupload.sendKeys(resumeupload);
	}

	public String getYearOfPassing() {
		return yearOfPassing.getAttribute("value");
	}


	public void setYearOfPassing(String yearOfPassing) {
		this.yearOfPassing.sendKeys(yearOfPassing);
	}


	public String getMedium() {
		return medium.getAttribute("value");
	}


	public void setMedium(String medium) {
		this.medium.sendKeys(medium);
	}


	public String getPercentage() {
		return percentage.getAttribute("value");
	}


	public void setPercentage(String percentage) {
		this.percentage.sendKeys(percentage);
	}


	public String getSkills() {
		return skills.getAttribute("value");
	}


	public void setSkills(String skills) {
		this.skills.sendKeys(skills);
	}


	public void clickFresherButton() {
		Fresherregisterbtn.click();
	}
	
	public void clickRegisterButton() {
		registerbtn.click();
	}
	
	public void clickQualification() {
		qualification.click();
	}
	
	public void clickSelectQualification() {
		selectQualification.click();
	}

    public void clickBoard() {
    	board.click();
    }
    
    public void clickSelectBoard() {
    	selectBoard.click();
    }
    
    public void clickYearOfPassing() {
    	yearOfPassing.click();
    }
    
    public void clickSelectYearOfPassing() {
    	selectYearOfPassing.click();
    }
    
    public void clickMedium() {
    	medium.click();
    }
    
    public void clickSelectMedium() {
    	selectMedium.click();
    }
    
    public void clickPercentage() {
    	percentage.click();
    }
    
    public void clickSelectPercentage() {
    	selectPercentage.click();
    }

   

	public void clickContinueButton() {
		continueButton.click();
	}
	
	public void clickSkipStep() {
		skipStep.click();
	}
}

		

