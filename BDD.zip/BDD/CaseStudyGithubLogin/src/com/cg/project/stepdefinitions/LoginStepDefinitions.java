package com.cg.project.stepdefinitions;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.project.beans.Loginpage;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;


public class LoginStepDefinitions {
	
	private WebDriver driver;
	private Loginpage loginpage;
	
	@Before
	public void setupStepEnv() {
		System.setProperty("webdriver.chrome.driver", "D:\\Softwares\\chromedriver.exe");
	}
	
	@Given("^User is on Github login Page$")
	public void user_is_on_Github_login_Page() throws Throwable {
		driver = new ChromeDriver();
		driver.get("https://github.com/login");
		loginpage = new Loginpage();
		PageFactory.initElements(driver, loginpage);
	}

	@When("^user enter Invalid username and password$")
	public void user_enter_Invalid_username_and_password() throws Throwable {
		loginpage.setUsername("AravindaMucha1");
		loginpage.setPassword("Arvi@1");
		loginpage.clickSubmitButton();
	}

	@Then("^'Incorrect username or password\\.' Message should display$")
	public void incorrect_username_or_password_Message_should_display() throws Throwable {
	    String actualErrorMessage = driver.findElement(By.xpath("//*[@id=\"js-flash-container\"]/div/div")).getText();
	    String expectedErrorMessage = "Incorrect username or password.";
	    Assert.assertEquals(expectedErrorMessage, actualErrorMessage);
	    
	}

	@When("^user enter valid username and password$")
	public void user_enter_valid_username_and_password() throws Throwable {
		loginpage.setUsername("AravindaMucha");
		loginpage.setPassword("Aravinda@204");
		loginpage.clickSubmitButton();
	}

	@Then("^user should successfully Signin on his Github Account$")
	public void user_should_successfully_Signin_on_his_Github_Account() throws Throwable {
		String actualTitle = driver.getTitle();
		String expectedTitle = "GitHub";
		Assert.assertEquals(expectedTitle, actualTitle);
	}
}
