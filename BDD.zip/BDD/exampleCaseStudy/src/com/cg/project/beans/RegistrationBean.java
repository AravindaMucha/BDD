package com.cg.project.beans;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class RegistrationBean {
	
	@FindBy(how = How.NAME, name = "fname")
	WebElement firstName;
	
	@FindBy(how = How.NAME, name = "lname")
	WebElement lastName;
	
	@FindBy(how = How.NAME, name = "email")
	WebElement email;
	
	@FindBy(how = How.NAME, name = "contact")
	WebElement contactNo;
	
	@FindBy(how = How.NAME, name = "address")
	WebElement address;
	
	@FindBy(how = How.NAME, name = "city")
	WebElement city;
	
	@FindBy(how=How.ID, id = "hobbies")
	List<WebElement> hobbies;
	
	@FindBy(how=How.NAME, name="gender")
	List<WebElement> gender;
	
	@FindBy(how=How.NAME, name = "state")
	WebElement state;
	
	@FindBy(how=How.NAME, name="submit")
	WebElement submitBtn;

	public RegistrationBean() {
	
	}

	public String getFirstName() {
		return firstName.getAttribute("value");
	}

	public void setFirstName(String firstName) {
		this.firstName.sendKeys(firstName);
	}

	public String getLastName() {
		return lastName.getAttribute("value");
	}

	public void setLastName(String lastName) {
		this.lastName.sendKeys(lastName);
	}

	public String getEmail() {
		return email.getAttribute("value");
	}

	public void setEmail(String email) {
		this.email.sendKeys(email);
	}

	public String getContactNo() {
		return contactNo.getAttribute("value");
	}

	public void setContactNo(String contactNo) {
		this.contactNo.sendKeys(contactNo);
	}

	public String getAddress() {
		return address.getAttribute("value");
	}

	public void setAddress(String address) {
		this.address.sendKeys(address);
	}

	public String getCity() {
		return city.getAttribute("value");
	}

	public void setCity(String city) {
		this.city.sendKeys(city);
	}
	
	public String getState() {
		return state.getAttribute("value");
	}

	public void setState(String state) {
		this.state.sendKeys(state);
	}

	public void checkboxList(List<String> hobbies_values) {
		for(int i = 0; i < hobbies_values.size(); i++) {
			for(WebElement checkbox: hobbies) {
				if(checkbox.getAttribute("value").contains(hobbies_values.get(i)))
					checkbox.click();
			}
		}
		
	}
	
	
	public void radioChooseGender(String choose) {
		for(WebElement radio:gender) {
			if(radio.getAttribute("value").contains(choose))
				radio.click();
		}
	}
	
	
	public void clickSubmitButton() {
    	submitBtn.click();
    }
	
}
