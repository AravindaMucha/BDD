package com.cg.project.stepdefinitions;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.Alert;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.project.beans.RegistrationBean;

import cucumber.api.PendingException;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefinitions {
	
	public WebDriver driver;
	public RegistrationBean registerBean;
	
	@Before
	public void setupStepEnv() {
		System.setProperty("webdriver.chrome.driver", "D:\\Softwares\\chromedriver.exe");
	}
	
	
	@Given("^User is on registration Page$")
	public void user_is_on_registration_Page() throws Throwable {
		driver = new ChromeDriver();
		driver.get("D:\\Practice\\BDD\\exampleCaseStudy\\registration.html");
		registerBean = new RegistrationBean();
		PageFactory.initElements(driver, registerBean);
	}
	
	@When("^user enters Firstname$")
	public void user_enters_Firstname() throws Throwable {
	    registerBean.setFirstName("Aravinda");
	}

	@When("^user enters LastName$")
	public void user_enters_LastName() throws Throwable {
	    registerBean.setLastName("Mucha");
	}

	@When("^user enters Email$")
	public void user_enters_Email() throws Throwable {
	    registerBean.setEmail("aravindaMucha@gmail.com");
	}

	@When("^user enters Contact Number$")
	public void user_enters_Contact_Number() throws Throwable {
	    registerBean.setContactNo("9652160279");
	}

	@When("^user enters Address$")
	public void user_enters_Address() throws Throwable {
	   registerBean.setAddress("");
	}

	@When("^user enters City$")
	public void user_enters_City() throws Throwable {
	    registerBean.setCity("HYD");
	}

	@When("^user enters checkbox$")
	
	public void user_enters_checkbox() throws Throwable {
		
		List<String> values = new ArrayList<>();
		values.add("singing");
		values.add("reading");
		registerBean.checkboxList(values);		
	}

	@When("^user enters gender$")
	public void user_enters_gender() throws Throwable {
	   registerBean.radioChooseGender("female");
	}

	@When("^user selects State$")
	public void user_selects_State() throws Throwable {
	    registerBean.setState("Goa");
	}

	@When("^user clicks on Submi button$")
	public void user_clicks_on_Submit_button() throws Throwable {
	   registerBean.clickSubmitButton();
	}

	@Then("^user should Successfully register$")
	public void user_should_Successfully_register() throws Throwable {
		Alert jsAlert = driver.switchTo().alert();
		if(jsAlert.getText().equals("validated"))
		{
			Thread.sleep(1000);
			jsAlert.accept();
			driver.navigate().to("D:\\Practice\\BDD\\exampleCaseStudy\\NextPage.html");
			
		}
		else
		{
			
		}
	}

}
