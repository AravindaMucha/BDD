package com.cg.project.stepdefinitions;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class SampleStepDefinition {
	
	public WebDriver driver;
	
	@Before(order = 1)
	public void setupStepEnv() {
		System.setProperty("webdriver.chrome.driver", "D:\\Softwares\\chromedriver.exe");
	}
	
	@Given("^user want to login to 'www\\.github\\.com'$")
	public void user_want_to_login_to_www_github_com() throws Throwable {
		driver = new ChromeDriver();
	}

	@When("^user will open google chrome$")
	public void user_will_open_google_chrome() throws Throwable {
		driver.get("https://github.com/login");
	}

	@When("^user enters 'AravindaMucha' in username field and 'ABC' in password field$")
	public void user_enters_AravindaMucha_in_username_field_and_ABC_in_password_field() throws Throwable {
		driver.findElement(By.id("login_field")).sendKeys("AravindaMucha");
		driver.findElement(By.id("password")).sendKeys("ABC");
		
	}

	@Then("^display login invalid password$")
	public void display_login_invalid_password() throws Throwable {
		driver.findElement(By.xpath("//*[@id=\"login\"]/form/div[3]/input[3]")).click();
	}

	@When("^user enters 'ABC' in username field and 'Aravinda@(\\d+)' in password field$")
	public void user_enters_ABC_in_username_field_and_Aravinda_in_password_field(int arg1) throws Throwable {
		driver.findElement(By.id("login_field")).sendKeys("ABC");
		driver.findElement(By.id("password")).sendKeys("Aravinda@204");
		
	}

	@Then("^display login invalid username$")
	public void display_login_invalid_username() throws Throwable {
		driver.findElement(By.xpath("//*[@id=\"login\"]/form/div[3]/input[3]")).click();
	}

	@When("^user enters 'AravindaMucha' in username field and 'Aravinda@(\\d+)' in password field$")
	public void user_enters_AravindaMucha_in_username_field_and_Aravinda_in_password_field(int arg1) throws Throwable {
		driver.findElement(By.id("login_field")).sendKeys("AravindaMucha");
		driver.findElement(By.id("password")).sendKeys("Aravinda@204");
	}

	@Then("^dispaly the home page of 'www\\.github\\.com'$")
	public void dispaly_the_home_page_of_www_github_com() throws Throwable {
		driver.findElement(By.xpath("//*[@id=\"login\"]/form/div[3]/input[3]")).click();
	}
}
